package com.yedam.web.dao;

public interface TimeDAO {
	public String getTime();
}
