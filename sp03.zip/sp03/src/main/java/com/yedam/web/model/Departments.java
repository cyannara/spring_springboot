package com.yedam.web.model;

import lombok.Data;

@Data
public class Departments {
	private String departmentId;
	private String departmentName;
	private String managerId;
	private String locationId;
}
