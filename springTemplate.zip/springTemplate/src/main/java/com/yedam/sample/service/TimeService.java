package com.yedam.sample.service;

public interface TimeService {

	public String getTime();

	public String getTime2();

}
