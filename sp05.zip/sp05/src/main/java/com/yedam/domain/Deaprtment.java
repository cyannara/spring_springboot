package com.yedam.domain;

import lombok.Data;

@Data
public class Deaprtment {
	private String departmentId;
	private String departmentName;
}
