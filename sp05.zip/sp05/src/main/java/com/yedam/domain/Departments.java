package com.yedam.domain;

import lombok.Data;

@Data
public class Departments {
	private String departmentId;
	private String departmentName;
	private String managerId;
	private String locationId;
}
