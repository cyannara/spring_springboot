package com.yedam.domain;

import lombok.Data;

//VO == DTO == DO
@Data
public class SampleDTO {
	private String name;
	private int age;
}
