package com.company.sample.service;

public interface SampleTxService {

	public void addData(String value);
}
