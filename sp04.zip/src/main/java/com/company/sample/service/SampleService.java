package com.company.sample.service;

public interface SampleService {
	
	public void sample(String name);
	
}
