package com.yedam.domain;

import lombok.Data;

@Data
public class EmployeesDepartmentVO {
	private String employeeId;
	private String firstName;
	private Deaprtment department;
}
